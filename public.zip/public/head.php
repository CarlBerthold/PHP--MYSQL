<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <link href="css/tailwindcss.css" rel="stylesheet">
        <title>Calculator</title>
    </head>